<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class DownloadExtra extends Model
{
  protected $table = 'download_extras';
}
