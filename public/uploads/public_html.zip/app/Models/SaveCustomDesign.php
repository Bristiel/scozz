<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class SaveCustomDesign extends Model
{
  protected $table = 'save_custom_designs';
}
